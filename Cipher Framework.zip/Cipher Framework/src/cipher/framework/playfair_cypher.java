/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cipher.framework;

/**
 *
 * @author Omer & MIKS
 */
public class playfair_cypher implements Cipher_Interface {

    @Override
    public void generate_key() {
        
    }

    @Override
    public void encrypt() {
        
    }

    @Override
    public void decrypt() {
        
    }

    @Override
    public void cryptoanalysis() {
        
    }
    
}
